HelloDropbox Sample Application
===============================

This is a minimalistic app intended to demonstrate the basics of
integrating with the Dropbox Sync SDK for Android.

* Pre-requisites:

Required Android API Level: 4 to run or build

This app can be built after importing into Eclipse with the ADT
plug-in.  In order to build and run this app, you must first copy the
appropriate libraries from the SDK libs/ directory to the sample app's
libs/ directory.  See the tutorial for more information.
